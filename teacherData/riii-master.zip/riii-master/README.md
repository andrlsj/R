﻿# R 語言基礎

Slides:
https://www.slideshare.net/secret/2U5tlBaC4MGCLZ

Password:
riii

## Download R
- http://cran.csie.ntu.edu.tw/bin/windows/base/R-3.3.1-win.exe 
- http://course.largitdata.com/course/33

## Download RStudio
- https://download1.rstudio.org/RStudio-1.0.44.exe 
- http://course.largitdata.com/course/34
